# TermFlow — Animation Kit

Animated, vector-based brand assets for the PGP schedule PWA. Everything is SVG
(crisp at any size), respects `prefers-reduced-motion`, and needs no JS to animate
(the React file is just a convenience wrapper).

## Files
| File | Use |
|---|---|
| `termflow-loader.svg` | **Indeterminate loader** — orbiting comet + breathing glow, loops forever. Show during data fetches / auto-refresh polling. |
| `termflow-splash.svg` | **Splash build-up** — the 6-beat sequence (ripple→path→flow→direction→compass→brand). Plays once on first paint. |
| `termflow-logo.svg` | **Horizontal lockup** — mark + "TermFlow" wordmark + tagline. Header / footer / share cards. |
| `termflow-icon.svg` | **App icon / favicon** — rounded tile. |
| `termflow-icon-maskable.svg` | **Maskable PWA icon** — full-bleed, safe-zone centered (Android adaptive icons). |
| `TermFlowLoader.jsx` | React component, `variant="spin"` (default) or `variant="splash"`. |
| `icon-512.png` `icon-192.png` `apple-touch-icon.png` `favicon-32.png` | PNG fallbacks for the manifest / iOS / browser tab. |
| `termflow-preview.html` | Open in a browser to see everything animate live. |

## React
```jsx
import TermFlowLoader from "./TermFlowLoader";

<TermFlowLoader size={72} />                    // spinner while schedule loads
<TermFlowLoader variant="splash" size={180} />  // splash on first paint
```

## Plain HTML
```html
<img src="/termflow-loader.svg" width="72" alt="Loading">
<link rel="icon" href="/termflow-icon.svg">
```

## manifest.webmanifest (PWA)
```json
{
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
  ],
  "theme_color": "#7c3aed",
  "background_color": "#0a0420"
}
```

## index.html head
```html
<link rel="icon" type="image/svg+xml" href="/termflow-icon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```

## Notes
- The wordmark in `termflow-logo.svg` uses live text (Poppins/Montserrat italic 800).
  Make sure that font is loaded on the site, or outline the text in your design tool
  for a pixel-locked logo.
- Brand colors: deep base `#0a0420`, violet `#7c3aed`, bright `#a855f7`, accent `#c77dff`.
